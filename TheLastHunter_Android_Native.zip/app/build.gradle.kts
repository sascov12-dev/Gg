plugins {
    id("com.android.application")
}

android {
    namespace = "app.bronze6658.lychee6856"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.bronze6658.lychee6856"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
