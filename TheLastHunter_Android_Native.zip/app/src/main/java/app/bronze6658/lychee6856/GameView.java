package app.bronze6658.lychee6856;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

public final class GameView extends View {

    private static final String PREFS = "the_last_hunter_save";

    private static final String[] ENEMY_NAMES = {
            "МОГИЛЬНЫЙ СКЕЛЕТ",
            "ПРОКЛЯТАЯ ГОНЧАЯ",
            "ПАДШИЙ РЫЦАРЬ",
            "БОЛОТНЫЙ УПЫРЬ",
            "ТЕНЕВОЙ КУЛЬТИСТ",
            "ДЕМОН БЕЗДНЫ"
    };

    private static final int[] BASE_HP = {
            20, 30, 45, 60, 80, 150
    };

    private static final int[] BASE_REWARD = {
            5, 8, 12, 18, 25, 60
    };

    private enum Screen {
        MENU,
        GAME
    }

    private enum Modal {
        NONE,
        SETTINGS,
        PAUSE,
        COMING_SOON
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;

    private Screen screen = Screen.MENU;
    private Modal modal = Modal.NONE;

    private final RectF primaryButton = new RectF();
    private final RectF secondaryButton = new RectF();
    private final RectF leftFeatureButton = new RectF();
    private final RectF rightFeatureButton = new RectF();
    private final RectF gearButton = new RectF();
    private final RectF modalButton1 = new RectF();
    private final RectF modalButton2 = new RectF();
    private final RectF modalButton3 = new RectF();
    private final RectF modalButton4 = new RectF();

    private int coins;
    private int cycle = 1;
    private int enemyIndex;
    private int currentHp;
    private int comboCounter;

    private boolean started;
    private boolean tutorialCompleted;
    private boolean musicEnabled = true;
    private boolean sfxEnabled = true;

    private boolean enemyTransitioning;
    private long hitFlashUntil;
    private long strongFlashUntil;
    private long coinFlashUntil;
    private long lastFrameTime;

    private String comingSoonTitle = "";
    private String floatingText = "";

    private float hunterKick;
    private float enemyShake;

    public GameView(Context context) {
        super(context);
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        setBackgroundColor(Color.rgb(5, 7, 10));
        setFocusable(true);
        setClickable(true);

        loadSettingsOnly();
        started = prefs.getBoolean("started", false);

        lastFrameTime = SystemClock.uptimeMillis();
    }

    public void onHostPaused() {
        if (screen == Screen.GAME && started) {
            saveProgress();
        }
    }

    public void onHostResumed() {
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.033f, Math.max(0f, (now - lastFrameTime) / 1000f));
        lastFrameTime = now;

        hunterKick += (0f - hunterKick) * Math.min(1f, dt * 14f);
        enemyShake += (0f - enemyShake) * Math.min(1f, dt * 20f);

        drawForest(canvas, now);

        if (screen == Screen.MENU) {
            drawMenu(canvas, now);
        } else {
            drawGame(canvas, now);
        }

        if (modal != Modal.NONE) {
            drawModal(canvas);
        }

        if (now < hitFlashUntil || now < strongFlashUntil || now < coinFlashUntil
                || Math.abs(hunterKick) > 0.2f || Math.abs(enemyShake) > 0.2f) {
            postInvalidateOnAnimation();
        }
    }

    private void drawForest(Canvas canvas, long now) {
        int w = getWidth();
        int h = getHeight();

        canvas.drawColor(Color.rgb(6, 9, 13));

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(23, 35, 47));
        canvas.drawCircle(w * 0.72f, h * 0.19f, w * 0.12f, paint);

        paint.setColor(Color.argb(120, 63, 92, 115));
        canvas.drawCircle(w * 0.72f, h * 0.19f, w * 0.105f, paint);

        paint.setColor(Color.rgb(13, 18, 23));
        for (int i = 0; i < 8; i++) {
            float x = w * (i / 7f);
            float baseY = h * 0.77f;
            float treeH = h * (0.36f + (i % 3) * 0.04f);
            float trunkW = Math.max(9f, w * 0.025f);

            canvas.drawRect(
                    x - trunkW / 2f,
                    baseY - treeH,
                    x + trunkW / 2f,
                    baseY,
                    paint
            );

            float by = baseY - treeH * 0.73f;
            drawBranch(canvas, x, by, -w * 0.10f, -h * 0.07f, trunkW * 0.55f);
            drawBranch(canvas, x, by + h * 0.06f, w * 0.11f, -h * 0.06f, trunkW * 0.50f);
        }

        paint.setColor(Color.rgb(25, 24, 23));
        canvas.drawRect(0, h * 0.76f, w, h, paint);

        paint.setColor(Color.argb(45, 110, 135, 153));
        float drift = (now % 7000L) / 7000f;
        for (int i = 0; i < 4; i++) {
            float x = w * (-0.25f + ((drift + i * 0.31f) % 1.35f));
            float y = h * (0.55f + i * 0.055f);
            canvas.drawOval(
                    new RectF(
                            x,
                            y,
                            x + w * 0.62f,
                            y + h * 0.055f
                    ),
                    paint
            );
        }

        drawGravestone(canvas, w * 0.12f, h * 0.79f, w * 0.055f, h * 0.065f);
        drawGravestone(canvas, w * 0.88f, h * 0.81f, w * 0.048f, h * 0.056f);
    }

    private void drawBranch(Canvas canvas, float x, float y, float dx, float dy, float thickness) {
        paint.setStrokeWidth(thickness);
        paint.setStrokeCap(Paint.Cap.SQUARE);
        canvas.drawLine(x, y, x + dx, y + dy, paint);
    }

    private void drawGravestone(Canvas canvas, float cx, float bottom, float ww, float hh) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(52, 57, 61));

        RectF r = new RectF(cx - ww / 2f, bottom - hh, cx + ww / 2f, bottom);
        canvas.drawRoundRect(r, ww * 0.2f, ww * 0.2f, paint);

        paint.setColor(Color.rgb(20, 22, 24));
        paint.setStrokeWidth(Math.max(2f, ww * 0.08f));
        canvas.drawLine(cx, bottom - hh * 0.62f, cx, bottom - hh * 0.28f, paint);
        canvas.drawLine(cx - ww * 0.16f, bottom - hh * 0.50f, cx + ww * 0.16f, bottom - hh * 0.50f, paint);
    }

    private void drawMenu(Canvas canvas, long now) {
        int w = getWidth();
        int h = getHeight();

        drawTitle(canvas, w * 0.5f, h * 0.12f);

        drawHunter(canvas, w * 0.5f, h * 0.48f, w * 0.34f, true, now);

        float buttonW = w * 0.76f;
        float buttonH = h * 0.073f;
        float left = (w - buttonW) / 2f;

        primaryButton.set(left, h * 0.77f, left + buttonW, h * 0.77f + buttonH);
        secondaryButton.set(left, h * 0.86f, left + buttonW, h * 0.86f + buttonH);

        drawMetalButton(
                canvas,
                primaryButton,
                started ? "ПРОДОЛЖИТЬ" : "ИГРАТЬ",
                true
        );

        drawMetalButton(canvas, secondaryButton, "НАСТРОЙКИ", false);

        setText(12f, Color.argb(120, 210, 219, 225), Paint.Align.CENTER, Paint.Typeface.NORMAL);
        canvas.drawText("ANDROID TEST BUILD", w * 0.5f, h * 0.965f, paint);
    }

    private void drawTitle(Canvas canvas, float cx, float topY) {
        setText(21f, Color.rgb(151, 169, 183), Paint.Align.CENTER, Paint.Typeface.BOLD);
        canvas.drawText("THE LAST", cx, topY, paint);

        setText(47f, Color.rgb(195, 207, 216), Paint.Align.CENTER, Paint.Typeface.BOLD);
        canvas.drawText("HUNTER", cx, topY + 52f, paint);

        paint.setColor(Color.argb(150, 126, 143, 155));
        paint.setStrokeWidth(2f);
        canvas.drawLine(cx - 90f, topY + 66f, cx + 90f, topY + 66f, paint);
    }

    private void drawGame(Canvas canvas, long now) {
        int w = getWidth();
        int h = getHeight();

        drawTopHud(canvas);
        drawEnemyHud(canvas);

        float hunterX = w * 0.28f + hunterKick;
        float enemyX = w * 0.72f + enemyShake;

        drawHunter(canvas, hunterX, h * 0.58f, w * 0.28f, false, now);
        drawEnemy(canvas, enemyX, h * 0.56f, w * 0.25f, now);

        if (!tutorialCompleted && !enemyTransitioning) {
            RectF tutorial = new RectF(w * 0.12f, h * 0.70f, w * 0.88f, h * 0.755f);
            paint.setColor(Color.argb(155, 0, 0, 0));
            canvas.drawRect(tutorial, paint);
            setText(14f, Color.rgb(225, 230, 233), Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText(
                    "КОСНИСЬ ЭКРАНА, ЧТОБЫ АТАКОВАТЬ",
                    w * 0.5f,
                    tutorial.centerY() + 5f,
                    paint
            );
        }

        leftFeatureButton.set(w * 0.06f, h * 0.88f, w * 0.48f, h * 0.945f);
        rightFeatureButton.set(w * 0.52f, h * 0.88f, w * 0.94f, h * 0.945f);

        drawMetalButton(canvas, leftFeatureButton, "УЛУЧШЕНИЯ", false);
        drawMetalButton(canvas, rightFeatureButton, "СПУТНИК", false);

        if (!floatingText.isEmpty()) {
            int color = now < coinFlashUntil
                    ? Color.rgb(214, 180, 92)
                    : Color.rgb(236, 236, 232);

            setText(20f, color, Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText(floatingText, w * 0.5f, h * 0.39f, paint);
        }
    }

    private void drawTopHud(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();

        RectF coinPanel = new RectF(w * 0.035f, h * 0.025f, w * 0.30f, h * 0.082f);
        drawPanel(canvas, coinPanel);

        paint.setColor(Color.rgb(173, 138, 62));
        canvas.drawCircle(coinPanel.left + 20f, coinPanel.centerY(), 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(Color.rgb(219, 188, 101));
        canvas.drawCircle(coinPanel.left + 20f, coinPanel.centerY(), 8f, paint);
        paint.setStyle(Paint.Style.FILL);

        setText(18f, Color.rgb(226, 215, 190), Paint.Align.LEFT, Paint.Typeface.BOLD);
        canvas.drawText(
                String.valueOf(coins),
                coinPanel.left + 42f,
                coinPanel.centerY() + 6f,
                paint
        );

        RectF cyclePanel = new RectF(w * 0.36f, h * 0.025f, w * 0.67f, h * 0.082f);
        drawPanel(canvas, cyclePanel);

        setText(13f, Color.rgb(183, 197, 208), Paint.Align.CENTER, Paint.Typeface.BOLD);
        canvas.drawText("ЦИКЛ " + cycle, cyclePanel.centerX(), cyclePanel.top + 19f, paint);

        setText(11f, enemyIndex == 5 ? Color.rgb(207, 61, 56) : Color.rgb(180, 185, 189),
                Paint.Align.CENTER, Paint.Typeface.BOLD);
        canvas.drawText(
                enemyIndex == 5 ? "БОСС" : (enemyIndex + 1) + " / 6",
                cyclePanel.centerX(),
                cyclePanel.bottom - 8f,
                paint
        );

        gearButton.set(w * 0.84f, h * 0.025f, w * 0.955f, h * 0.082f);
        drawPanel(canvas, gearButton);

        setText(21f, Color.rgb(188, 199, 208), Paint.Align.CENTER, Paint.Typeface.BOLD);
        canvas.drawText("⚙", gearButton.centerX(), gearButton.centerY() + 7f, paint);
    }

    private void drawEnemyHud(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();

        RectF hud = new RectF(w * 0.06f, h * 0.105f, w * 0.94f, h * 0.17f);
        drawPanel(canvas, hud);

        setText(
                enemyIndex == 5 ? 14f : 12f,
                enemyIndex == 5 ? bossNameColor() : Color.rgb(215, 219, 222),
                Paint.Align.LEFT,
                Paint.Typeface.BOLD
        );

        canvas.drawText(
                ENEMY_NAMES[enemyIndex],
                hud.left + 10f,
                hud.top + 21f,
                paint
        );

        setText(11f, Color.rgb(166, 171, 175), Paint.Align.RIGHT, Paint.Typeface.BOLD);
        canvas.drawText(
                currentHp + " / " + currentEnemyMaxHp(),
                hud.right - 10f,
                hud.top + 21f,
                paint
        );

        float ratio = currentEnemyMaxHp() <= 0
                ? 0f
                : Math.max(0f, Math.min(1f, currentHp / (float) currentEnemyMaxHp()));

        RectF bg = new RectF(hud.left + 10f, hud.bottom - 20f, hud.right - 10f, hud.bottom - 8f);
        paint.setColor(Color.rgb(12, 12, 13));
        canvas.drawRect(bg, paint);

        paint.setColor(enemyIndex == 5 ? bossHpColor() : Color.rgb(114, 31, 31));
        canvas.drawRect(
                new RectF(bg.left, bg.top, bg.left + bg.width() * ratio, bg.bottom),
                paint
        );

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(enemyIndex == 5 ? 2f : 1f);
        paint.setColor(enemyIndex == 5 ? Color.rgb(120, 42, 40) : Color.rgb(75, 84, 90));
        canvas.drawRect(bg, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private int bossNameColor() {
        float ratio = currentHp / (float) Math.max(1, currentEnemyMaxHp());

        if (ratio > 0.60f) {
            return Color.rgb(195, 181, 174);
        } else if (ratio > 0.30f) {
            return Color.rgb(220, 139, 116);
        } else {
            return Color.rgb(240, 101, 82);
        }
    }

    private int bossHpColor() {
        float ratio = currentHp / (float) Math.max(1, currentEnemyMaxHp());

        if (ratio > 0.60f) {
            return Color.rgb(148, 34, 34);
        } else if (ratio > 0.30f) {
            return Color.rgb(179, 33, 31);
        } else {
            return Color.rgb(214, 46, 41);
        }
    }

    private void drawHunter(Canvas canvas, float cx, float cy, float size, boolean backView, long now) {
        float bob = (float) Math.sin(now / 420.0) * 2.0f;
        float top = cy - size * 0.57f + bob;
        float bottom = cy + size * 0.53f + bob;

        paint.setColor(Color.argb(130, 0, 0, 0));
        canvas.drawOval(
                new RectF(cx - size * 0.34f, bottom - 6f, cx + size * 0.34f, bottom + 12f),
                paint
        );

        Path cloak = new Path();
        cloak.moveTo(cx - size * 0.17f, top + size * 0.28f);
        cloak.lineTo(cx + size * 0.17f, top + size * 0.28f);
        cloak.lineTo(cx + size * 0.34f, bottom);
        cloak.lineTo(cx + size * 0.12f, bottom - size * 0.05f);
        cloak.lineTo(cx, bottom);
        cloak.lineTo(cx - size * 0.19f, bottom - size * 0.03f);
        cloak.lineTo(cx - size * 0.34f, bottom);
        cloak.close();

        paint.setColor(Color.rgb(9, 11, 14));
        canvas.drawPath(cloak, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, size * 0.012f));
        paint.setColor(Color.rgb(59, 65, 70));
        canvas.drawPath(cloak, paint);
        paint.setStyle(Paint.Style.FILL);

        paint.setColor(Color.rgb(58, 65, 70));
        canvas.drawRect(
                cx - size * 0.32f,
                top + size * 0.30f,
                cx - size * 0.13f,
                top + size * 0.38f,
                paint
        );
        canvas.drawRect(
                cx + size * 0.13f,
                top + size * 0.30f,
                cx + size * 0.32f,
                top + size * 0.38f,
                paint
        );

        paint.setColor(Color.rgb(6, 7, 9));
        canvas.drawCircle(cx, top + size * 0.18f, size * 0.18f, paint);

        if (!backView) {
            paint.setColor(Color.rgb(64, 220, 101));
            canvas.drawCircle(cx - size * 0.055f, top + size * 0.18f, size * 0.018f, paint);
            canvas.drawCircle(cx + size * 0.055f, top + size * 0.18f, size * 0.018f, paint);
        }

        drawSword(
                canvas,
                cx + size * 0.28f,
                cy + size * 0.10f,
                size * 0.48f,
                backView ? -14f : -28f
        );
    }

    private void drawSword(Canvas canvas, float cx, float cy, float length, float degrees) {
        canvas.save();
        canvas.rotate(degrees, cx, cy);

        paint.setColor(Color.rgb(173, 184, 191));
        canvas.drawRect(cx - 3f, cy - length * 0.55f, cx + 3f, cy + length * 0.15f, paint);

        paint.setColor(Color.rgb(169, 137, 67));
        canvas.drawRect(cx - 16f, cy + length * 0.10f, cx + 16f, cy + length * 0.14f, paint);

        paint.setColor(Color.rgb(20, 20, 22));
        canvas.drawRect(cx - 4f, cy + length * 0.14f, cx + 4f, cy + length * 0.29f, paint);

        canvas.restore();
    }

    private void drawEnemy(Canvas canvas, float cx, float cy, float size, long now) {
        float bob = (float) Math.sin(now / 350.0 + enemyIndex) * 2.0f;
        cy += bob;

        int bodyColor;
        int detailColor;

        switch (enemyIndex) {
            case 0:
                bodyColor = Color.rgb(175, 176, 163);
                detailColor = Color.rgb(80, 72, 63);
                break;
            case 1:
                bodyColor = Color.rgb(55, 45, 43);
                detailColor = Color.rgb(166, 57, 47);
                break;
            case 2:
                bodyColor = Color.rgb(69, 75, 79);
                detailColor = Color.rgb(134, 55, 45);
                break;
            case 3:
                bodyColor = Color.rgb(66, 85, 65);
                detailColor = Color.rgb(128, 120, 74);
                break;
            case 4:
                bodyColor = Color.rgb(47, 40, 55);
                detailColor = Color.rgb(126, 72, 142);
                break;
            default:
                bodyColor = bossHpColor();
                detailColor = Color.rgb(40, 15, 15);
                break;
        }

        paint.setColor(Color.argb(120, 0, 0, 0));
        canvas.drawOval(
                new RectF(cx - size * 0.38f, cy + size * 0.42f, cx + size * 0.38f, cy + size * 0.53f),
                paint
        );

        if (enemyIndex == 1) {
            Path dog = new Path();
            dog.moveTo(cx - size * 0.42f, cy + size * 0.20f);
            dog.lineTo(cx - size * 0.23f, cy - size * 0.10f);
            dog.lineTo(cx + size * 0.22f, cy - size * 0.05f);
            dog.lineTo(cx + size * 0.43f, cy + size * 0.16f);
            dog.lineTo(cx + size * 0.22f, cy + size * 0.31f);
            dog.lineTo(cx - size * 0.28f, cy + size * 0.32f);
            dog.close();

            paint.setColor(bodyColor);
            canvas.drawPath(dog, paint);
        } else {
            paint.setColor(bodyColor);
            canvas.drawOval(
                    new RectF(
                            cx - size * 0.27f,
                            cy - size * 0.18f,
                            cx + size * 0.27f,
                            cy + size * 0.40f
                    ),
                    paint
            );

            canvas.drawCircle(cx, cy - size * 0.31f, size * 0.18f, paint);
        }

        if (enemyIndex == 5) {
            Path leftHorn = new Path();
            leftHorn.moveTo(cx - size * 0.12f, cy - size * 0.42f);
            leftHorn.lineTo(cx - size * 0.38f, cy - size * 0.63f);
            leftHorn.lineTo(cx - size * 0.22f, cy - size * 0.29f);
            leftHorn.close();

            Path rightHorn = new Path();
            rightHorn.moveTo(cx + size * 0.12f, cy - size * 0.42f);
            rightHorn.lineTo(cx + size * 0.38f, cy - size * 0.63f);
            rightHorn.lineTo(cx + size * 0.22f, cy - size * 0.29f);
            rightHorn.close();

            paint.setColor(detailColor);
            canvas.drawPath(leftHorn, paint);
            canvas.drawPath(rightHorn, paint);
        }

        paint.setColor(detailColor);
        canvas.drawCircle(cx - size * 0.055f, cy - size * 0.31f, size * 0.018f, paint);
        canvas.drawCircle(cx + size * 0.055f, cy - size * 0.31f, size * 0.018f, paint);

        if (SystemClock.uptimeMillis() < hitFlashUntil) {
            paint.setColor(Color.argb(80, 255, 255, 255));
            canvas.drawCircle(cx, cy, size * 0.48f, paint);
        }
    }

    private void drawModal(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();

        paint.setColor(Color.argb(190, 0, 0, 0));
        canvas.drawRect(0, 0, w, h, paint);

        RectF panel = new RectF(w * 0.11f, h * 0.27f, w * 0.89f, h * 0.73f);
        drawPanel(canvas, panel);

        if (modal == Modal.SETTINGS) {
            setText(26f, Color.rgb(204, 213, 219), Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText("НАСТРОЙКИ", panel.centerX(), panel.top + 54f, paint);

            modalButton1.set(panel.left + 24f, panel.top + 92f, panel.right - 24f, panel.top + 146f);
            modalButton2.set(panel.left + 24f, panel.top + 158f, panel.right - 24f, panel.top + 212f);
            modalButton3.set(panel.left + 24f, panel.bottom - 74f, panel.right - 24f, panel.bottom - 20f);

            drawToggleButton(canvas, modalButton1, "МУЗЫКА", musicEnabled);
            drawToggleButton(canvas, modalButton2, "ЗВУКИ", sfxEnabled);
            drawMetalButton(canvas, modalButton3, "ЗАКРЫТЬ", true);

        } else if (modal == Modal.PAUSE) {
            setText(28f, Color.rgb(204, 213, 219), Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText("ПАУЗА", panel.centerX(), panel.top + 50f, paint);

            modalButton1.set(panel.left + 24f, panel.top + 82f, panel.right - 24f, panel.top + 134f);
            modalButton2.set(panel.left + 24f, panel.top + 146f, panel.right - 24f, panel.top + 198f);
            modalButton3.set(panel.left + 24f, panel.top + 218f, panel.right - 24f, panel.top + 270f);
            modalButton4.set(panel.left + 24f, panel.top + 282f, panel.right - 24f, panel.top + 334f);

            drawToggleButton(canvas, modalButton1, "МУЗЫКА", musicEnabled);
            drawToggleButton(canvas, modalButton2, "ЗВУКИ", sfxEnabled);
            drawMetalButton(canvas, modalButton3, "ПРОДОЛЖИТЬ", true);
            drawMetalButton(canvas, modalButton4, "ВЫЙТИ В МЕНЮ", false);

        } else if (modal == Modal.COMING_SOON) {
            setText(12f, Color.argb(120, 220, 225, 229), Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText(comingSoonTitle, panel.centerX(), panel.top + 72f, paint);

            setText(32f, Color.rgb(200, 210, 216), Paint.Align.CENTER, Paint.Typeface.BOLD);
            canvas.drawText("СКОРО", panel.centerX(), panel.top + 135f, paint);

            setText(14f, Color.rgb(175, 180, 184), Paint.Align.CENTER, Paint.Typeface.NORMAL);
            canvas.drawText("Функция появится позже", panel.centerX(), panel.top + 176f, paint);

            modalButton1.set(panel.left + 30f, panel.bottom - 90f, panel.right - 30f, panel.bottom - 34f);
            drawMetalButton(canvas, modalButton1, "ЗАКРЫТЬ", true);
        }
    }

    private void drawToggleButton(Canvas canvas, RectF rect, String title, boolean enabled) {
        drawPanel(canvas, rect);

        setText(14f, Color.rgb(200, 207, 212), Paint.Align.LEFT, Paint.Typeface.BOLD);
        canvas.drawText(title, rect.left + 15f, rect.centerY() + 5f, paint);

        setText(
                14f,
                enabled ? Color.rgb(101, 205, 119) : Color.rgb(176, 82, 76),
                Paint.Align.RIGHT,
                Paint.Typeface.BOLD
        );
        canvas.drawText(enabled ? "ВКЛ" : "ВЫКЛ", rect.right - 15f, rect.centerY() + 5f, paint);
    }

    private void drawPanel(Canvas canvas, RectF rect) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(235, 10, 12, 15));
        canvas.drawRect(rect, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f);
        paint.setColor(Color.rgb(73, 82, 89));
        canvas.drawRect(rect, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawMetalButton(Canvas canvas, RectF rect, String text, boolean emphasized) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(emphasized ? Color.rgb(20, 24, 28) : Color.rgb(12, 15, 18));
        canvas.drawRect(rect, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(emphasized ? 2f : 1f);
        paint.setColor(emphasized ? Color.rgb(111, 125, 135) : Color.rgb(72, 81, 88));
        canvas.drawRect(rect, paint);

        paint.setStyle(Paint.Style.FILL);

        setText(
                emphasized ? 16f : 14f,
                emphasized ? Color.rgb(224, 231, 235) : Color.rgb(190, 199, 205),
                Paint.Align.CENTER,
                Paint.Typeface.BOLD
        );

        canvas.drawText(text, rect.centerX(), rect.centerY() + 6f, paint);
    }

    private void setText(float sp, int color, Paint.Align align, int style) {
        float density = getResources().getDisplayMetrics().scaledDensity;

        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(sp * density);
        paint.setColor(color);
        paint.setTextAlign(align);
        paint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SERIF, style));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) {
            return true;
        }

        float x = event.getX();
        float y = event.getY();

        if (modal != Modal.NONE) {
            handleModalTap(x, y);
            invalidate();
            return true;
        }

        if (screen == Screen.MENU) {
            if (primaryButton.contains(x, y)) {
                if (started) {
                    continueGame();
                } else {
                    startNewGame();
                }
            } else if (secondaryButton.contains(x, y)) {
                modal = Modal.SETTINGS;
            }

            invalidate();
            return true;
        }

        if (gearButton.contains(x, y)) {
            modal = Modal.PAUSE;
            saveProgress();
            invalidate();
            return true;
        }

        if (leftFeatureButton.contains(x, y)) {
            comingSoonTitle = "УЛУЧШЕНИЯ";
            modal = Modal.COMING_SOON;
            invalidate();
            return true;
        }

        if (rightFeatureButton.contains(x, y)) {
            comingSoonTitle = "СПУТНИК";
            modal = Modal.COMING_SOON;
            invalidate();
            return true;
        }

        attack();
        return true;
    }

    private void handleModalTap(float x, float y) {
        if (modal == Modal.SETTINGS) {
            if (modalButton1.contains(x, y)) {
                musicEnabled = !musicEnabled;
                saveSettings();
            } else if (modalButton2.contains(x, y)) {
                sfxEnabled = !sfxEnabled;
                saveSettings();
            } else if (modalButton3.contains(x, y)) {
                modal = Modal.NONE;
            }

        } else if (modal == Modal.PAUSE) {
            if (modalButton1.contains(x, y)) {
                musicEnabled = !musicEnabled;
                saveSettings();
                saveProgress();
            } else if (modalButton2.contains(x, y)) {
                sfxEnabled = !sfxEnabled;
                saveSettings();
                saveProgress();
            } else if (modalButton3.contains(x, y)) {
                modal = Modal.NONE;
            } else if (modalButton4.contains(x, y)) {
                saveProgress();
                screen = Screen.MENU;
                modal = Modal.NONE;
            }

        } else if (modal == Modal.COMING_SOON) {
            if (modalButton1.contains(x, y)) {
                modal = Modal.NONE;
            }
        }
    }

    private void attack() {
        if (enemyTransitioning || currentHp <= 0) {
            return;
        }

        if (!tutorialCompleted) {
            tutorialCompleted = true;
        }

        comboCounter += 1;

        int damage;

        if (comboCounter % 10 == 0) {
            damage = 5;
            floatingText = "КРИТ!  -5";
            strongFlashUntil = SystemClock.uptimeMillis() + 240L;
        } else if (comboCounter % 5 == 0) {
            damage = 3;
            floatingText = "СИЛЬНЫЙ УДАР  -3";
            strongFlashUntil = SystemClock.uptimeMillis() + 180L;
        } else {
            damage = 1;
            floatingText = "-1";
        }

        hunterKick = 18f;
        enemyShake = -12f;

        hitFlashUntil = SystemClock.uptimeMillis() + 100L;

        currentHp = Math.max(0, currentHp - damage);

        if (currentHp <= 0) {
            defeatEnemy();
        } else {
            saveProgress();
        }

        invalidate();
    }

    private void defeatEnemy() {
        enemyTransitioning = true;

        int reward = currentEnemyReward();
        coins += reward;

        floatingText = "+" + reward + " МОНЕТ";
        coinFlashUntil = SystemClock.uptimeMillis() + 500L;

        saveProgress();

        postDelayed(() -> {
            if (enemyIndex >= ENEMY_NAMES.length - 1) {
                enemyIndex = 0;
                cycle += 1;
            } else {
                enemyIndex += 1;
            }

            currentHp = currentEnemyMaxHp();
            enemyTransitioning = false;
            floatingText = "";

            saveProgress();
            invalidate();
        }, 520L);
    }

    private void startNewGame() {
        coins = 0;
        cycle = 1;
        enemyIndex = 0;
        comboCounter = 0;
        tutorialCompleted = false;
        started = true;
        currentHp = currentEnemyMaxHp();

        screen = Screen.GAME;
        modal = Modal.NONE;

        saveProgress();
        invalidate();
    }

    private void continueGame() {
        loadProgress();

        screen = Screen.GAME;
        modal = Modal.NONE;

        invalidate();
    }

    private int currentEnemyMaxHp() {
        return scaledValue(BASE_HP[enemyIndex]);
    }

    private int currentEnemyReward() {
        return scaledValue(BASE_REWARD[enemyIndex]);
    }

    private int scaledValue(int base) {
        float multiplier = 1f + 0.25f * Math.max(0, cycle - 1);
        return Math.max(1, Math.round(base * multiplier));
    }

    private void loadProgress() {
        coins = prefs.getInt("coins", 0);
        cycle = Math.max(1, prefs.getInt("cycle", 1));

        enemyIndex = prefs.getInt("enemyIndex", 0);
        if (enemyIndex < 0 || enemyIndex >= ENEMY_NAMES.length) {
            enemyIndex = 0;
        }

        comboCounter = Math.max(0, prefs.getInt("comboCounter", 0));
        tutorialCompleted = prefs.getBoolean("tutorialCompleted", false);
        musicEnabled = prefs.getBoolean("musicEnabled", true);
        sfxEnabled = prefs.getBoolean("sfxEnabled", true);
        started = prefs.getBoolean("started", false);

        int maxHp = currentEnemyMaxHp();
        currentHp = prefs.getInt("currentHp", maxHp);

        if (currentHp <= 0 || currentHp > maxHp) {
            currentHp = maxHp;
        }
    }

    private void loadSettingsOnly() {
        musicEnabled = prefs.getBoolean("musicEnabled", true);
        sfxEnabled = prefs.getBoolean("sfxEnabled", true);
    }

    private void saveSettings() {
        prefs.edit()
                .putBoolean("musicEnabled", musicEnabled)
                .putBoolean("sfxEnabled", sfxEnabled)
                .apply();
    }

    private void saveProgress() {
        prefs.edit()
                .putInt("coins", coins)
                .putInt("cycle", cycle)
                .putInt("enemyIndex", enemyIndex)
                .putInt("currentHp", currentHp)
                .putInt("comboCounter", comboCounter)
                .putBoolean("tutorialCompleted", tutorialCompleted)
                .putBoolean("musicEnabled", musicEnabled)
                .putBoolean("sfxEnabled", sfxEnabled)
                .putBoolean("started", started)
                .apply();
    }
}
