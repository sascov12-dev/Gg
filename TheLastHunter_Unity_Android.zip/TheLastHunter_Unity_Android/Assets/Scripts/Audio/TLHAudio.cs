using UnityEngine;

namespace TheLastHunter
{
    public sealed class TLHAudio : MonoBehaviour
    {
        private AudioSource musicSource;
        private AudioSource sfxSource;

        private GameController controller;

        public void Initialize(GameController gameController)
        {
            controller = gameController;

            musicSource = gameObject.AddComponent<AudioSource>();
            musicSource.loop = true;
            musicSource.playOnAwake = false;
            musicSource.volume = 0.55f;

            sfxSource = gameObject.AddComponent<AudioSource>();
            sfxSource.loop = false;
            sfxSource.playOnAwake = false;
            sfxSource.volume = 0.85f;
        }

        public void RefreshSettings()
        {
            if (controller == null || controller.State == null)
                return;

            musicSource.mute = !controller.State.musicEnabled;
            sfxSource.mute = !controller.State.sfxEnabled;
        }

        public void PlayMenuMusic()
        {
            PlayMusic("Audio/menu");
        }

        public void PlayBattleMusic(bool boss)
        {
            PlayMusic(boss ? "Audio/boss" : "Audio/battle");
        }

        public void PlaySfx(string resourcePath)
        {
            if (controller == null || !controller.State.sfxEnabled)
                return;

            var clip = Resources.Load<AudioClip>(resourcePath);
            if (clip != null)
                sfxSource.PlayOneShot(clip);
        }

        private void PlayMusic(string resourcePath)
        {
            if (controller == null)
                return;

            var clip = Resources.Load<AudioClip>(resourcePath);
            if (clip == null)
            {
                musicSource.Stop();
                musicSource.clip = null;
                return;
            }

            if (musicSource.clip == clip && musicSource.isPlaying)
                return;

            musicSource.clip = clip;
            musicSource.mute = !controller.State.musicEnabled;
            musicSource.Play();
        }
    }
}
