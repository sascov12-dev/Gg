using UnityEngine;

namespace TheLastHunter
{
    // Temporary fallback pixel silhouettes so the Unity port runs before final art is added.
    // Real sprites from Assets/Resources/Sprites override these automatically.
    public static class RuntimeSpriteFactory
    {
        public static Sprite Hunter()
        {
            var tex = NewTexture(48, 64);
            Clear(tex);

            // Cloak/body
            Fill(tex, 14, 18, 33, 52, new Color32(18, 20, 23, 255));
            Fill(tex, 10, 38, 37, 60, new Color32(12, 14, 16, 255));
            Fill(tex, 17, 9, 30, 24, new Color32(7, 8, 9, 255));

            // Armor
            Fill(tex, 15, 25, 20, 37, new Color32(58, 65, 70, 255));
            Fill(tex, 27, 25, 32, 37, new Color32(58, 65, 70, 255));

            // Green eyes
            Fill(tex, 20, 16, 22, 17, new Color32(74, 255, 111, 255));
            Fill(tex, 26, 16, 28, 17, new Color32(74, 255, 111, 255));

            // Sword
            Fill(tex, 35, 20, 38, 54, new Color32(175, 184, 190, 255));
            Fill(tex, 32, 23, 41, 25, new Color32(161, 126, 58, 255));

            tex.Apply();
            return MakeSprite(tex);
        }

        public static Sprite Enemy(int index, bool boss)
        {
            var tex = NewTexture(48, 64);
            Clear(tex);

            Color32 body = boss
                ? new Color32(75, 18, 18, 255)
                : new Color32((byte)(64 + index * 9), (byte)(66 + index * 5), (byte)(70 + index * 6), 255);

            Fill(tex, 12, 20, 35, 55, body);
            Fill(tex, 16, 10, 31, 27, body);
            Fill(tex, 8, 30, 14, 46, body);
            Fill(tex, 34, 30, 40, 46, body);

            if (boss)
            {
                Fill(tex, 13, 5, 17, 14, new Color32(45, 8, 8, 255));
                Fill(tex, 30, 5, 34, 14, new Color32(45, 8, 8, 255));
                Fill(tex, 19, 17, 22, 19, new Color32(255, 84, 54, 255));
                Fill(tex, 26, 17, 29, 19, new Color32(255, 84, 54, 255));
            }
            else
            {
                Fill(tex, 20, 17, 22, 19, new Color32(178, 40, 40, 255));
                Fill(tex, 26, 17, 28, 19, new Color32(178, 40, 40, 255));
            }

            tex.Apply();
            return MakeSprite(tex);
        }

        public static Sprite MenuHunterBack()
        {
            var tex = NewTexture(48, 72);
            Clear(tex);
            Fill(tex, 14, 13, 33, 29, new Color32(8, 9, 10, 255));
            Fill(tex, 10, 25, 37, 67, new Color32(12, 13, 15, 255));
            Fill(tex, 16, 31, 21, 44, new Color32(52, 58, 62, 255));
            Fill(tex, 27, 31, 32, 44, new Color32(52, 58, 62, 255));
            Fill(tex, 36, 25, 39, 63, new Color32(174, 183, 188, 255));
            tex.Apply();
            return MakeSprite(tex);
        }

        private static Texture2D NewTexture(int width, int height)
        {
            var tex = new Texture2D(width, height, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            return tex;
        }

        private static void Clear(Texture2D tex)
        {
            var pixels = new Color32[tex.width * tex.height];
            for (int i = 0; i < pixels.Length; i++)
                pixels[i] = new Color32(0, 0, 0, 0);
            tex.SetPixels32(pixels);
        }

        private static void Fill(Texture2D tex, int x0, int y0, int x1, int y1, Color32 color)
        {
            for (int y = y0; y <= y1; y++)
            {
                for (int x = x0; x <= x1; x++)
                {
                    if (x >= 0 && y >= 0 && x < tex.width && y < tex.height)
                        tex.SetPixel(x, y, color);
                }
            }
        }

        private static Sprite MakeSprite(Texture2D tex)
        {
            return Sprite.Create(
                tex,
                new Rect(0, 0, tex.width, tex.height),
                new Vector2(0.5f, 0.5f),
                32f,
                0,
                SpriteMeshType.FullRect
            );
        }
    }
}
