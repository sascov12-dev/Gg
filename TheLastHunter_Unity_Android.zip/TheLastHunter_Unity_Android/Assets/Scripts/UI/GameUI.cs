using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheLastHunter
{
    public sealed class GameUI : MonoBehaviour
    {
        private GameController game;
        private TLHAudio audioManager;

        private Canvas canvas;
        private Font font;

        private GameObject menuPanel;
        private GameObject gamePanel;
        private GameObject pausePanel;
        private GameObject settingsPanel;
        private GameObject comingSoonPanel;

        private Text coinsText;
        private Text cycleText;
        private Text enemyNameText;
        private Text enemyHpText;
        private Text tutorialText;
        private Image enemyHpFill;
        private Image hunterImage;
        private Image enemyImage;
        private Text continueLabel;
        private Button continueButton;
        private Text pauseMusicValue;
        private Text pauseSfxValue;
        private Text settingsMusicValue;
        private Text settingsSfxValue;
        private Text comingSoonTitle;

        private Vector2 hunterBasePos;
        private Color enemyBaseColor = Color.white;

        public void Initialize(GameController controller, TLHAudio tlhAudio)
        {
            game = controller;
            audioManager = tlhAudio;

            font = Resources.GetBuiltinResource<Font>("Arial.ttf");

            EnsureEventSystem();
            BuildCanvas();
            BuildMenu();
            BuildGame();
            BuildPause();
            BuildSettings();
            BuildComingSoon();

            game.StateChanged += RefreshAll;
            game.AttackStarted += OnAttackStarted;
            game.DamageApplied += OnDamageApplied;
            game.EnemyDefeated += OnEnemyDefeated;
            game.EnemyChanged += OnEnemyChanged;

            ShowMenu();
            RefreshAll();
        }

        private void Update()
        {
            if (!game.IsInGame || gamePanel == null || !gamePanel.activeSelf)
                return;

            if (pausePanel.activeSelf || comingSoonPanel.activeSelf || settingsPanel.activeSelf)
                return;

            if (Input.touchCount > 0)
            {
                var touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Began)
                {
                    bool overUi = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(touch.fingerId);
                    if (!overUi)
                        game.TryAttack();
                }
            }
            else if (Input.GetMouseButtonDown(0))
            {
                bool overUi = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();
                if (!overUi)
                    game.TryAttack();
            }
        }

        private void EnsureEventSystem()
        {
            if (EventSystem.current != null)
                return;

            var go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
        }

        private void BuildCanvas()
        {
            var go = new GameObject("Canvas");
            canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            var scaler = go.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            go.AddComponent<GraphicRaycaster>();
        }

        private void BuildMenu()
        {
            menuPanel = Panel("Menu", canvas.transform, new Color32(8, 12, 18, 255));

            var forestShade = Image("ForestShade", menuPanel.transform, new Color32(17, 30, 42, 255));
            Stretch(forestShade.rectTransform, 0, 0, 1, 1);

            var moon = Image("Moon", menuPanel.transform, new Color32(98, 126, 145, 48));
            SetRect(moon.rectTransform, 730, 1420, 250, 250);

            var title1 = Label("THE LAST", menuPanel.transform, 56, FontStyle.Bold, new Color32(151, 169, 185, 255));
            SetRect(title1.rectTransform, 0, 1630, 1080, 80);
            title1.alignment = TextAnchor.MiddleCenter;

            var title2 = Label("HUNTER", menuPanel.transform, 128, FontStyle.Bold, new Color32(201, 211, 218, 255));
            SetRect(title2.rectTransform, 0, 1490, 1080, 150);
            title2.alignment = TextAnchor.MiddleCenter;

            var hunter = Image("MenuHunter", menuPanel.transform, Color.white);
            var menuSprite = Resources.Load<Sprite>("Sprites/Hunter/hunter_menu_back");
            hunter.sprite = menuSprite != null ? menuSprite : RuntimeSpriteFactory.MenuHunterBack();
            hunter.preserveAspect = true;
            SetRect(hunter.rectTransform, 315, 680, 450, 720);

            continueButton = MakeButton("Continue", menuPanel.transform, "ПРОДОЛЖИТЬ", 52, () =>
            {
                game.ContinueGame();
                ShowGame();
            });
            SetRect(continueButton.GetComponent<RectTransform>(), 210, 370, 660, 120);
            continueLabel = continueButton.GetComponentInChildren<Text>();

            var play = MakeButton("Play", menuPanel.transform, "ИГРАТЬ", 54, () =>
            {
                game.StartNewGame();
                ShowGame();
            });
            SetRect(play.GetComponent<RectTransform>(), 210, 220, 660, 120);

            var settings = MakeButton("Settings", menuPanel.transform, "НАСТРОЙКИ", 46, () =>
            {
                OpenSettings();
            });
            SetRect(settings.GetComponent<RectTransform>(), 210, 70, 660, 110);
        }

        private void BuildGame()
        {
            gamePanel = Panel("Game", canvas.transform, new Color32(6, 11, 16, 255));
            gamePanel.SetActive(false);

            var bg = Image("Forest", gamePanel.transform, new Color32(18, 31, 41, 255));
            Stretch(bg.rectTransform, 0, 0, 1, 1);

            var ground = Image("Ground", gamePanel.transform, new Color32(39, 33, 29, 255));
            SetRect(ground.rectTransform, 0, 0, 1080, 540);

            coinsText = Label("0", gamePanel.transform, 46, FontStyle.Bold, new Color32(225, 208, 167, 255));
            SetRect(coinsText.rectTransform, 40, 1790, 320, 80);

            cycleText = Label("ЦИКЛ 1 · 1/6", gamePanel.transform, 38, FontStyle.Bold, new Color32(185, 197, 207, 255));
            SetRect(cycleText.rectTransform, 330, 1790, 420, 80);
            cycleText.alignment = TextAnchor.MiddleCenter;

            var gear = MakeButton("PauseButton", gamePanel.transform, "⚙", 54, OpenPause);
            SetRect(gear.GetComponent<RectTransform>(), 920, 1785, 110, 90);

            enemyNameText = Label("ENEMY", gamePanel.transform, 36, FontStyle.Bold, new Color32(230, 232, 234, 255));
            SetRect(enemyNameText.rectTransform, 90, 1655, 900, 70);
            enemyNameText.alignment = TextAnchor.MiddleCenter;

            var hpBack = Image("HPBack", gamePanel.transform, new Color32(17, 17, 19, 255));
            SetRect(hpBack.rectTransform, 130, 1590, 820, 38);

            enemyHpFill = Image("HPFill", hpBack.transform, new Color32(125, 32, 32, 255));
            Stretch(enemyHpFill.rectTransform, 0, 0, 1, 1);
            enemyHpFill.rectTransform.pivot = new Vector2(0, 0.5f);

            enemyHpText = Label("20 / 20", gamePanel.transform, 30, FontStyle.Bold, new Color32(220, 220, 220, 255));
            SetRect(enemyHpText.rectTransform, 315, 1530, 450, 55);
            enemyHpText.alignment = TextAnchor.MiddleCenter;

            hunterImage = Image("Hunter", gamePanel.transform, Color.white);
            var hunterSprite = Resources.Load<Sprite>("Sprites/Hunter/hunter_battle");
            hunterImage.sprite = hunterSprite != null ? hunterSprite : RuntimeSpriteFactory.Hunter();
            hunterImage.preserveAspect = true;
            SetRect(hunterImage.rectTransform, 130, 610, 360, 620);
            hunterBasePos = hunterImage.rectTransform.anchoredPosition;

            enemyImage = Image("Enemy", gamePanel.transform, Color.white);
            enemyImage.preserveAspect = true;
            SetRect(enemyImage.rectTransform, 600, 650, 360, 560);

            tutorialText = Label("КОСНИСЬ ЭКРАНА, ЧТОБЫ АТАКОВАТЬ", gamePanel.transform, 34, FontStyle.Bold, new Color32(235, 235, 235, 220));
            SetRect(tutorialText.rectTransform, 115, 500, 850, 110);
            tutorialText.alignment = TextAnchor.MiddleCenter;

            var upgrades = MakeButton("Upgrades", gamePanel.transform, "УЛУЧШЕНИЯ", 40, () => OpenComingSoon("УЛУЧШЕНИЯ"));
            SetRect(upgrades.GetComponent<RectTransform>(), 50, 65, 470, 115);

            var companion = MakeButton("Companion", gamePanel.transform, "СПУТНИК", 40, () => OpenComingSoon("СПУТНИК"));
            SetRect(companion.GetComponent<RectTransform>(), 560, 65, 470, 115);
        }

        private void BuildPause()
        {
            pausePanel = Panel("Pause", canvas.transform, new Color32(0, 0, 0, 190));
            pausePanel.SetActive(false);

            var box = Panel("PauseBox", pausePanel.transform, new Color32(15, 18, 22, 248));
            SetRect(box.GetComponent<RectTransform>(), 160, 560, 760, 780);

            var title = Label("ПАУЗА", box.transform, 72, FontStyle.Bold, new Color32(205, 214, 220, 255));
            SetRect(title.rectTransform, 0, 620, 760, 110);
            title.alignment = TextAnchor.MiddleCenter;

            var music = MakeButton("Music", box.transform, "МУЗЫКА", 42, () =>
            {
                game.ToggleMusic();
                audioManager.RefreshSettings();
                RefreshAll();
            });
            SetRect(music.GetComponent<RectTransform>(), 80, 450, 600, 105);
            pauseMusicValue = ValueLabel(music.transform);

            var sfx = MakeButton("Sfx", box.transform, "ЗВУКИ", 42, () =>
            {
                game.ToggleSfx();
                audioManager.RefreshSettings();
                RefreshAll();
            });
            SetRect(sfx.GetComponent<RectTransform>(), 80, 320, 600, 105);
            pauseSfxValue = ValueLabel(sfx.transform);

            var resume = MakeButton("Resume", box.transform, "ПРОДОЛЖИТЬ", 42, ClosePause);
            SetRect(resume.GetComponent<RectTransform>(), 80, 170, 600, 105);

            var exit = MakeButton("Exit", box.transform, "ВЫЙТИ В ГЛАВНОЕ МЕНЮ", 30, () =>
            {
                Time.timeScale = 1f;
                game.ExitToMenu();
                ShowMenu();
            });
            SetRect(exit.GetComponent<RectTransform>(), 80, 40, 600, 105);
        }

        private void BuildSettings()
        {
            settingsPanel = Panel("Settings", canvas.transform, new Color32(0, 0, 0, 195));
            settingsPanel.SetActive(false);

            var box = Panel("SettingsBox", settingsPanel.transform, new Color32(15, 18, 22, 250));
            SetRect(box.GetComponent<RectTransform>(), 170, 655, 740, 610);

            var title = Label("НАСТРОЙКИ", box.transform, 58, FontStyle.Bold, new Color32(205, 214, 220, 255));
            SetRect(title.rectTransform, 0, 470, 740, 100);
            title.alignment = TextAnchor.MiddleCenter;

            var music = MakeButton("MenuMusic", box.transform, "МУЗЫКА", 42, () =>
            {
                if (game.State == null) return;
                game.ToggleMusic();
                audioManager.RefreshSettings();
                RefreshAll();
            });
            SetRect(music.GetComponent<RectTransform>(), 70, 315, 600, 105);
            settingsMusicValue = ValueLabel(music.transform);

            var sfx = MakeButton("MenuSfx", box.transform, "ЗВУКИ", 42, () =>
            {
                if (game.State == null) return;
                game.ToggleSfx();
                audioManager.RefreshSettings();
                RefreshAll();
            });
            SetRect(sfx.GetComponent<RectTransform>(), 70, 180, 600, 105);
            settingsSfxValue = ValueLabel(sfx.transform);

            var close = MakeButton("Close", box.transform, "ЗАКРЫТЬ", 40, () => settingsPanel.SetActive(false));
            SetRect(close.GetComponent<RectTransform>(), 70, 45, 600, 105);
        }

        private void BuildComingSoon()
        {
            comingSoonPanel = Panel("ComingSoon", canvas.transform, new Color32(0, 0, 0, 190));
            comingSoonPanel.SetActive(false);

            var box = Panel("SoonBox", comingSoonPanel.transform, new Color32(15, 18, 22, 250));
            SetRect(box.GetComponent<RectTransform>(), 180, 690, 720, 540);

            comingSoonTitle = Label("УЛУЧШЕНИЯ", box.transform, 32, FontStyle.Bold, new Color32(150, 156, 162, 255));
            SetRect(comingSoonTitle.rectTransform, 0, 390, 720, 70);
            comingSoonTitle.alignment = TextAnchor.MiddleCenter;

            var soon = Label("СКОРО", box.transform, 78, FontStyle.Bold, new Color32(205, 214, 220, 255));
            SetRect(soon.rectTransform, 0, 245, 720, 120);
            soon.alignment = TextAnchor.MiddleCenter;

            var desc = Label("Функция появится позже", box.transform, 36, FontStyle.Normal, new Color32(190, 194, 198, 230));
            SetRect(desc.rectTransform, 0, 175, 720, 70);
            desc.alignment = TextAnchor.MiddleCenter;

            var close = MakeButton("CloseSoon", box.transform, "ЗАКРЫТЬ", 40, () => comingSoonPanel.SetActive(false));
            SetRect(close.GetComponent<RectTransform>(), 80, 45, 560, 100);
        }

        private void ShowMenu()
        {
            menuPanel.SetActive(true);
            gamePanel.SetActive(false);
            pausePanel.SetActive(false);
            settingsPanel.SetActive(false);
            comingSoonPanel.SetActive(false);
            Time.timeScale = 1f;

            RefreshMenuButtons();
            audioManager.PlayMenuMusic();
            RefreshAll();
        }

        private void ShowGame()
        {
            menuPanel.SetActive(false);
            gamePanel.SetActive(true);
            pausePanel.SetActive(false);
            settingsPanel.SetActive(false);
            comingSoonPanel.SetActive(false);
            Time.timeScale = 1f;

            OnEnemyChanged();
            audioManager.PlayBattleMusic(game.CurrentEnemy.isBoss);
            audioManager.RefreshSettings();
            RefreshAll();
        }

        private void OpenPause()
        {
            if (!game.IsInGame) return;
            pausePanel.SetActive(true);
            Time.timeScale = 0f;
            RefreshAll();
        }

        private void ClosePause()
        {
            pausePanel.SetActive(false);
            Time.timeScale = 1f;
        }

        private void OpenSettings()
        {
            // Menu settings use persisted values even before a run starts.
            if (!game.IsInGame)
            {
                game.State.musicEnabled = SaveSystem.GetMusicSetting();
                game.State.sfxEnabled = SaveSystem.GetSfxSetting();
            }
            settingsPanel.SetActive(true);
            RefreshAll();
        }

        private void OpenComingSoon(string title)
        {
            comingSoonTitle.text = title;
            comingSoonPanel.SetActive(true);
        }

        private void RefreshMenuButtons()
        {
            continueButton.gameObject.SetActive(SaveSystem.HasSave);
            continueLabel.text = "ПРОДОЛЖИТЬ";
        }

        private void RefreshAll()
        {
            if (game == null || game.State == null)
                return;

            if (coinsText != null)
                coinsText.text = "◆ " + game.State.coins;

            if (cycleText != null)
            {
                string enemyCounter = game.CurrentEnemy.isBoss
                    ? "БОСС"
                    : (game.State.enemyIndex + 1) + "/" + GameDatabase.Enemies.Length;
                cycleText.text = "ЦИКЛ " + game.State.cycle + " · " + enemyCounter;
            }

            if (enemyNameText != null)
            {
                enemyNameText.text = game.CurrentEnemy.displayName;
                enemyNameText.color = game.CurrentEnemy.isBoss
                    ? BossColor(game.CurrentBossPhase)
                    : new Color32(230, 232, 234, 255);
            }

            if (enemyHpText != null)
                enemyHpText.text = game.State.enemyHP + " / " + game.CurrentEnemyMaxHP;

            if (enemyHpFill != null)
            {
                float ratio = game.CurrentEnemyMaxHP <= 0
                    ? 0f
                    : Mathf.Clamp01((float)game.State.enemyHP / game.CurrentEnemyMaxHP);

                var rt = enemyHpFill.rectTransform;
                rt.anchorMax = new Vector2(ratio, 1f);
                rt.offsetMin = Vector2.zero;
                rt.offsetMax = Vector2.zero;

                enemyHpFill.color = game.CurrentEnemy.isBoss
                    ? BossColor(game.CurrentBossPhase)
                    : new Color32(125, 32, 32, 255);
            }

            if (tutorialText != null)
                tutorialText.gameObject.SetActive(game.IsInGame && !game.State.tutorialCompleted);

            string music = game.State.musicEnabled ? "ВКЛ" : "ВЫКЛ";
            string sfx = game.State.sfxEnabled ? "ВКЛ" : "ВЫКЛ";

            if (pauseMusicValue != null) pauseMusicValue.text = music;
            if (pauseSfxValue != null) pauseSfxValue.text = sfx;
            if (settingsMusicValue != null) settingsMusicValue.text = music;
            if (settingsSfxValue != null) settingsSfxValue.text = sfx;

            RefreshMenuButtons();
        }

        private void OnEnemyChanged()
        {
            if (enemyImage == null || game == null)
                return;

            string resourcePath = "Sprites/Enemies/" + game.CurrentEnemy.id;
            var sprite = Resources.Load<Sprite>(resourcePath);
            enemyImage.sprite = sprite != null
                ? sprite
                : RuntimeSpriteFactory.Enemy(game.State.enemyIndex, game.CurrentEnemy.isBoss);

            enemyImage.color = Color.white;
            enemyBaseColor = enemyImage.color;
            enemyImage.rectTransform.localScale = Vector3.one;

            audioManager.PlayBattleMusic(game.CurrentEnemy.isBoss);
            RefreshAll();
        }

        private void OnAttackStarted(int hitNumber, int damage)
        {
            StartCoroutine(AttackVisual(hitNumber));
            audioManager.PlaySfx(hitNumber % 10 == 0 ? "Audio/critical" : "Audio/attack");
        }

        private void OnDamageApplied(int damage)
        {
            StartCoroutine(HitFlash());
            audioManager.PlaySfx("Audio/hit");
        }

        private void OnEnemyDefeated(int reward)
        {
            StartCoroutine(DeathVisual());
            audioManager.PlaySfx(game.CurrentEnemy.isBoss ? "Audio/boss_death" : "Audio/death");
        }

        private IEnumerator AttackVisual(int hitNumber)
        {
            if (hunterImage == null) yield break;

            var rt = hunterImage.rectTransform;
            Vector2 start = hunterBasePos;
            float distance = hitNumber % 10 == 0 ? 58f : (hitNumber % 5 == 0 ? 46f : 34f);

            rt.anchoredPosition = start + new Vector2(distance, 0);
            yield return new WaitForSeconds(0.08f);
            rt.anchoredPosition = start;
        }

        private IEnumerator HitFlash()
        {
            if (enemyImage == null) yield break;
            enemyImage.color = Color.white;
            enemyImage.rectTransform.localScale = new Vector3(1.04f, 1.04f, 1f);
            yield return new WaitForSeconds(0.07f);
            enemyImage.color = enemyBaseColor;
            enemyImage.rectTransform.localScale = Vector3.one;
        }

        private IEnumerator DeathVisual()
        {
            if (enemyImage == null) yield break;
            var start = enemyImage.color;
            for (int i = 0; i < 6; i++)
            {
                float a = 1f - (i + 1) / 6f;
                enemyImage.color = new Color(start.r, start.g, start.b, a);
                yield return new WaitForSeconds(0.045f);
            }
        }

        private Color BossColor(BossVisualPhase phase)
        {
            switch (phase)
            {
                case BossVisualPhase.Angry:
                    return new Color32(215, 126, 108, 255);
                case BossVisualPhase.Enraged:
                    return new Color32(240, 82, 63, 255);
                default:
                    return new Color32(200, 180, 174, 255);
            }
        }

        private Text ValueLabel(Transform parent)
        {
            var value = Label("ВКЛ", parent, 32, FontStyle.Bold, new Color32(113, 214, 132, 255));
            var rt = value.rectTransform;
            rt.anchorMin = new Vector2(0.72f, 0f);
            rt.anchorMax = new Vector2(0.97f, 1f);
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            value.alignment = TextAnchor.MiddleRight;
            return value;
        }

        private GameObject Panel(string name, Transform parent, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            var image = go.GetComponent<Image>();
            image.color = color;
            Stretch(go.GetComponent<RectTransform>(), 0, 0, 1, 1);
            return go;
        }

        private Image Image(string name, Transform parent, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            var image = go.GetComponent<Image>();
            image.color = color;
            return image;
        }

        private Text Label(string text, Transform parent, int size, FontStyle style, Color color)
        {
            var go = new GameObject("Text", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            go.transform.SetParent(parent, false);
            var label = go.GetComponent<Text>();
            label.font = font;
            label.text = text;
            label.fontSize = size;
            label.fontStyle = style;
            label.color = color;
            label.alignment = TextAnchor.MiddleLeft;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Overflow;
            return label;
        }

        private Button MakeButton(string name, Transform parent, string text, int fontSize, UnityEngine.Events.UnityAction action)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);

            var image = go.GetComponent<Image>();
            image.color = new Color32(28, 33, 38, 248);

            var button = go.GetComponent<Button>();
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color32(225, 230, 234, 255);
            colors.pressedColor = new Color32(180, 188, 196, 255);
            colors.selectedColor = Color.white;
            button.colors = colors;
            button.onClick.AddListener(action);

            var label = Label(text, go.transform, fontSize, FontStyle.Bold, new Color32(205, 214, 220, 255));
            Stretch(label.rectTransform, 0.03f, 0.05f, 0.97f, 0.95f);
            label.alignment = TextAnchor.MiddleCenter;

            return button;
        }

        private static void SetRect(RectTransform rt, float x, float y, float width, float height)
        {
            rt.anchorMin = new Vector2(0, 0);
            rt.anchorMax = new Vector2(0, 0);
            rt.pivot = new Vector2(0, 0);
            rt.anchoredPosition = new Vector2(x, y);
            rt.sizeDelta = new Vector2(width, height);
        }

        private static void Stretch(RectTransform rt, float minX, float minY, float maxX, float maxY)
        {
            rt.anchorMin = new Vector2(minX, minY);
            rt.anchorMax = new Vector2(maxX, maxY);
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }
    }
}
