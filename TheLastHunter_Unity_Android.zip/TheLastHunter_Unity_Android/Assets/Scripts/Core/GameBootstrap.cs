using UnityEngine;

namespace TheLastHunter
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        private void Awake()
        {
            Application.targetFrameRate = 60;
            Screen.orientation = ScreenOrientation.Portrait;

            var controller = gameObject.AddComponent<GameController>();
            var audioManager = gameObject.AddComponent<TLHAudio>();
            var ui = gameObject.AddComponent<GameUI>();

            audioManager.Initialize(controller);
            ui.Initialize(controller, audioManager);
        }
    }
}
