using System;
using UnityEngine;

namespace TheLastHunter
{
    public enum BossVisualPhase
    {
        Calm,
        Angry,
        Enraged
    }

    [Serializable]
    public sealed class EnemyDefinition
    {
        public string id;
        public string displayName;
        public int baseHP;
        public int baseReward;
        public bool isBoss;

        public EnemyDefinition(string id, string displayName, int baseHP, int baseReward, bool isBoss = false)
        {
            this.id = id;
            this.displayName = displayName;
            this.baseHP = baseHP;
            this.baseReward = baseReward;
            this.isBoss = isBoss;
        }
    }

    public static class GameDatabase
    {
        public static readonly EnemyDefinition[] Enemies =
        {
            new EnemyDefinition("grave_skeleton", "МОГИЛЬНЫЙ СКЕЛЕТ", 20, 5),
            new EnemyDefinition("cursed_hound", "ПРОКЛЯТАЯ ГОНЧАЯ", 30, 8),
            new EnemyDefinition("fallen_knight", "ПАДШИЙ РЫЦАРЬ", 45, 12),
            new EnemyDefinition("swamp_ghoul", "БОЛОТНЫЙ УПЫРЬ", 60, 18),
            new EnemyDefinition("shadow_cultist", "ТЕНЕВОЙ КУЛЬТИСТ", 80, 25),
            new EnemyDefinition("abyss_demon", "ДЕМОН БЕЗДНЫ", 150, 60, true)
        };

        public static float CycleMultiplier(int cycle)
        {
            return 1f + 0.25f * Mathf.Max(0, cycle - 1);
        }

        public static int ScaledHP(EnemyDefinition enemy, int cycle)
        {
            return Mathf.Max(1, Mathf.RoundToInt(enemy.baseHP * CycleMultiplier(cycle)));
        }

        public static int ScaledReward(EnemyDefinition enemy, int cycle)
        {
            return Mathf.Max(1, Mathf.RoundToInt(enemy.baseReward * CycleMultiplier(cycle)));
        }
    }
}
