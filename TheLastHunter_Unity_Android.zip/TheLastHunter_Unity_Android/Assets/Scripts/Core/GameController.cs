using System;
using System.Collections;
using UnityEngine;

namespace TheLastHunter
{
    public sealed class GameController : MonoBehaviour
    {
        public SaveData State { get; private set; }
        public bool IsInGame { get; private set; }
        public bool IsAttackBusy { get; private set; }

        public event Action StateChanged;
        public event Action<int, int> AttackStarted;
        public event Action<int> DamageApplied;
        public event Action<int> EnemyDefeated;
        public event Action EnemyChanged;

        private bool bufferedAttack;

        public EnemyDefinition CurrentEnemy =>
            GameDatabase.Enemies[Mathf.Clamp(State.enemyIndex, 0, GameDatabase.Enemies.Length - 1)];

        public int CurrentEnemyMaxHP => GameDatabase.ScaledHP(CurrentEnemy, State.cycle);
        public int CurrentReward => GameDatabase.ScaledReward(CurrentEnemy, State.cycle);

        public BossVisualPhase CurrentBossPhase
        {
            get
            {
                if (!CurrentEnemy.isBoss)
                    return BossVisualPhase.Calm;

                float ratio = CurrentEnemyMaxHP <= 0
                    ? 0f
                    : Mathf.Clamp01((float)State.enemyHP / CurrentEnemyMaxHP);

                if (ratio > 0.60f) return BossVisualPhase.Calm;
                if (ratio > 0.30f) return BossVisualPhase.Angry;
                return BossVisualPhase.Enraged;
            }
        }

        private void Awake()
        {
            State = SaveSystem.Fresh();
        }

        public void StartNewGame()
        {
            var fresh = SaveSystem.Fresh();
            fresh.hasStartedGame = true;
            fresh.cycle = 1;
            fresh.enemyIndex = 0;
            fresh.enemyHP = GameDatabase.ScaledHP(GameDatabase.Enemies[0], 1);
            fresh.comboCounter = 0;
            fresh.tutorialCompleted = false;

            State = fresh;
            IsInGame = true;
            bufferedAttack = false;
            IsAttackBusy = false;

            SaveNow();
            EnemyChanged?.Invoke();
            StateChanged?.Invoke();
        }

        public void ContinueGame()
        {
            var loaded = SaveSystem.Load();
            if (loaded == null || !loaded.hasStartedGame)
            {
                StartNewGame();
                return;
            }

            State = loaded;
            State.enemyIndex = Mathf.Clamp(State.enemyIndex, 0, GameDatabase.Enemies.Length - 1);
            State.cycle = Mathf.Max(1, State.cycle);

            int maxHP = GameDatabase.ScaledHP(CurrentEnemy, State.cycle);
            if (State.enemyHP <= 0 || State.enemyHP > maxHP)
                State.enemyHP = maxHP;

            IsInGame = true;
            bufferedAttack = false;
            IsAttackBusy = false;

            EnemyChanged?.Invoke();
            StateChanged?.Invoke();
        }

        public void ExitToMenu()
        {
            SaveNow();
            IsInGame = false;
            bufferedAttack = false;
            StateChanged?.Invoke();
        }

        public void TryAttack()
        {
            if (!IsInGame)
                return;

            if (IsAttackBusy)
            {
                bufferedAttack = true;
                return;
            }

            StartCoroutine(AttackRoutine());
        }

        private IEnumerator AttackRoutine()
        {
            IsAttackBusy = true;

            State.comboCounter += 1;
            int hitNumber = State.comboCounter;
            int damage = GetDamageForHit(hitNumber);

            AttackStarted?.Invoke(hitNumber, damage);

            // Damage lands on the visual contact moment.
            yield return new WaitForSeconds(0.10f);

            if (!State.tutorialCompleted)
                State.tutorialCompleted = true;

            State.enemyHP = Mathf.Max(0, State.enemyHP - damage);
            DamageApplied?.Invoke(damage);
            StateChanged?.Invoke();

            if (State.enemyHP <= 0)
            {
                int reward = CurrentReward;
                State.coins += reward;
                SaveNow();

                EnemyDefeated?.Invoke(reward);
                StateChanged?.Invoke();

                yield return new WaitForSeconds(0.38f);
                AdvanceEnemy();
            }

            yield return new WaitForSeconds(0.10f);
            IsAttackBusy = false;

            if (bufferedAttack && IsInGame)
            {
                bufferedAttack = false;
                StartCoroutine(AttackRoutine());
            }
        }

        private int GetDamageForHit(int hitNumber)
        {
            if (hitNumber % 10 == 0)
                return 5;

            if (hitNumber % 5 == 0)
                return 3;

            return 1;
        }

        private void AdvanceEnemy()
        {
            int next = State.enemyIndex + 1;

            if (next >= GameDatabase.Enemies.Length)
            {
                State.cycle += 1;
                next = 0;
            }

            State.enemyIndex = next;
            State.enemyHP = GameDatabase.ScaledHP(CurrentEnemy, State.cycle);

            SaveNow();
            EnemyChanged?.Invoke();
            StateChanged?.Invoke();
        }

        public void ToggleMusic()
        {
            State.musicEnabled = !State.musicEnabled;
            SaveSystem.SetMusicSetting(State.musicEnabled);
            SaveNow();
            StateChanged?.Invoke();
        }

        public void ToggleSfx()
        {
            State.sfxEnabled = !State.sfxEnabled;
            SaveSystem.SetSfxSetting(State.sfxEnabled);
            SaveNow();
            StateChanged?.Invoke();
        }

        public void SaveNow()
        {
            if (State == null)
                return;

            SaveSystem.Save(State);
        }

        private void OnApplicationPause(bool pause)
        {
            if (pause)
                SaveNow();
        }

        private void OnApplicationQuit()
        {
            SaveNow();
        }
    }
}
