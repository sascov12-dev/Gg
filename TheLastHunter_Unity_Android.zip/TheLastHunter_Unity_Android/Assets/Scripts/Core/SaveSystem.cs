using System;
using UnityEngine;

namespace TheLastHunter
{
    [Serializable]
    public sealed class SaveData
    {
        public int coins = 0;
        public int cycle = 1;
        public int enemyIndex = 0;
        public int enemyHP = 20;
        public int comboCounter = 0;
        public bool musicEnabled = true;
        public bool sfxEnabled = true;
        public bool hasStartedGame = false;
        public bool tutorialCompleted = false;
    }

    public static class SaveSystem
    {
        private const string SaveKey = "THE_LAST_HUNTER_SAVE_V1";
        private const string MusicKey = "THE_LAST_HUNTER_MUSIC";
        private const string SfxKey = "THE_LAST_HUNTER_SFX";

        public static bool HasSave
        {
            get
            {
                var data = Load();
                return data != null && data.hasStartedGame;
            }
        }

        public static SaveData Fresh()
        {
            return new SaveData
            {
                musicEnabled = GetMusicSetting(),
                sfxEnabled = GetSfxSetting()
            };
        }

        public static SaveData Load()
        {
            if (!PlayerPrefs.HasKey(SaveKey))
                return null;

            try
            {
                var json = PlayerPrefs.GetString(SaveKey, string.Empty);
                if (string.IsNullOrWhiteSpace(json))
                    return null;

                return JsonUtility.FromJson<SaveData>(json);
            }
            catch
            {
                return null;
            }
        }

        public static void Save(SaveData data)
        {
            if (data == null)
                return;

            PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(data));
            SetMusicSetting(data.musicEnabled);
            SetSfxSetting(data.sfxEnabled);
            PlayerPrefs.Save();
        }

        public static void SetMusicSetting(bool enabled)
        {
            PlayerPrefs.SetInt(MusicKey, enabled ? 1 : 0);
        }

        public static void SetSfxSetting(bool enabled)
        {
            PlayerPrefs.SetInt(SfxKey, enabled ? 1 : 0);
        }

        public static bool GetMusicSetting()
        {
            return PlayerPrefs.GetInt(MusicKey, 1) == 1;
        }

        public static bool GetSfxSetting()
        {
            return PlayerPrefs.GetInt(SfxKey, 1) == 1;
        }
    }
}
