#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace TheLastHunter.EditorTools
{
    public static class TheLastHunterBuilder
    {
        private const string ScenePath = "Assets/Scenes/Main.unity";
        private const string BundleId = "app.bronze6658.lychee6856";

        [MenuItem("The Last Hunter/Prepare Android Project")]
        public static void PrepareAndroidProject()
        {
            Directory.CreateDirectory("Assets/Scenes");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var cameraObject = new GameObject("Main Camera");
            var camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.black;
            cameraObject.tag = "MainCamera";

            new GameObject("GameBootstrap").AddComponent<TheLastHunter.GameBootstrap>();

            EditorSceneManager.SaveScene(scene, ScenePath);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(ScenePath, true)
            };

            PlayerSettings.productName = "The Last Hunter";
            PlayerSettings.companyName = "The Last Hunter";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, BundleId);
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.Mono2x);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;

            EditorUserBuildSettings.buildAppBundle = false;

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Debug.Log("The Last Hunter: Android project prepared.");
        }

        [MenuItem("The Last Hunter/Build Android APK")]
        public static void BuildAndroidApk()
        {
            PrepareAndroidProject();

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogError("Could not switch to Android. Install Android Build Support in Unity Hub.");
                return;
            }

            Directory.CreateDirectory("Builds/Android");

            var options = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = "Builds/Android/TheLastHunter.apk",
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                options = BuildOptions.None
            };

            var report = BuildPipeline.BuildPlayer(options);
            var summary = report.summary;

            if (summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
                Debug.Log("APK READY: " + Path.GetFullPath(options.locationPathName));
            else
                Debug.LogError("APK build failed: " + summary.result);
        }
    }
}
#endif
